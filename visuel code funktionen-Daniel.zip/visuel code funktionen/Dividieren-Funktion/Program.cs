﻿Console.WriteLine("Gib die erste Zahl ein");
string nummer1 = Console.ReadLine();
double Nummer1 = Convert.ToDouble(nummer1);
Console.WriteLine("Gib die zweite Zahl ein");
string nummer2 = Console.ReadLine();
double Nummer2 = Convert.ToDouble(nummer2);

double Resultat = Nummer1 / Nummer2;

Console.WriteLine("Dein Resultat ist " + Resultat);